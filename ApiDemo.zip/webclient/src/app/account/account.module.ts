import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AccountComponent } from "./account.component";
import { RegisterComponent } from "./register/register.component";
import { AccountRoutes } from "./account.routing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AcountService } from "./acount.service";
import { LoginComponent } from './login/login.component';
@NgModule({
  imports: [CommonModule, AccountRoutes, FormsModule],
  declarations: [AccountComponent, RegisterComponent,
    LoginComponent
],
  providers: [AcountService]
})
export class AccountModule {}
