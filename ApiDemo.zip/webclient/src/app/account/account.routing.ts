import { Routes, RouterModule } from "@angular/router";
import { RegisterComponent } from "./register/register.component";
import { LoginComponent } from "./login/login.component";
const routes: Routes = [
  {
    path: "reg",
    component: RegisterComponent
  },
  {
    path: "login",
    component: LoginComponent
  }
];

export const AccountRoutes = RouterModule.forChild(routes);
