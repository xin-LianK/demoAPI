import { Injectable } from "@angular/core";
import { environment } from "../../environments/environment";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
@Injectable()
export class AcountService {
  constructor(private http: HttpClient) {}
  login(username: string, password: string): Promise<LoginResult> {
    return this.http
      .post<LoginResult>(
        `${environment.apiBase}/token`,
        `username=${encodeURIComponent(
          username
        )}&password=${password}&grant_type=password`,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded"
          }
        }
      )
      .toPromise()
      .then(
        r => {
          window.sessionStorage.setItem("token", r.access_token);
          return r;
        },
        r => {
          if (r instanceof HttpErrorResponse) {
            Promise.reject(r.error.error_description);
          }
          return Promise.reject(r);
        }
      );
  }
  register(model: RegisterModel): Promise<void> {
    return this.http
      .post<void>(`${environment.apiBase}/api/account/register`, model)
      .toPromise()
      .catch(r => {
        if (r instanceof HttpErrorResponse) {
          return Promise.reject(r.error.Message);
        }
        return Promise.reject(r);
      });
  }
}
export class RegisterModel {
  Email: string;
  Password: string;
  ConfirmPassword: string;
}
export class LoginResult {
  access_token: string;
}
