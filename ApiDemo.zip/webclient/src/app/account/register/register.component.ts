import { Component, OnInit } from "@angular/core";
import { AcountService } from "../acount.service";
@Component({
  selector: "app-register",
  templateUrl: "./register.component.html",
  styleUrls: ["./register.component.css"]
})
export class RegisterComponent implements OnInit {
  email: string;
  password: string;
  confirmpassword: string;
  constructor(private accountService: AcountService) {}

  ngOnInit() {}
  submit() {
    this.accountService
      .register({
        Email: this.email,
        Password: this.password,
        ConfirmPassword: this.confirmpassword
      })
      .then(() => alert("注册成功"), r => alert(r));
  }
}
