import { Component, OnInit } from "@angular/core";
import { StuffModel, StuffService } from "../stuff.service";
@Component({
  selector: "app-add",
  templateUrl: "./add.component.html",
  styleUrls: ["./add.component.css"]
})
export class AddComponent implements OnInit {
  model: StuffModel = {};
  constructor(private stuffService: StuffService) {}

  ngOnInit() {}
  add() {
    this.stuffService.addStuff(this.model).then(r => alert("添加成功"));
  }
}
