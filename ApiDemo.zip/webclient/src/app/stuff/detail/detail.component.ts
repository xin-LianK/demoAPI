import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { StuffService, StuffModel } from "../stuff.service";

@Component({
  selector: "app-detail",
  templateUrl: "./detail.component.html",
  styleUrls: ["./detail.component.css"]
})
export class DetailComponent implements OnInit {
  id: number;
  stuff: StuffModel;
  constructor(
    private router: ActivatedRoute,
    private stuffService: StuffService
  ) {
    router.params.subscribe(d => {
      if (Object.prototype.hasOwnProperty.call(d, "id")) {
        this.id = Number.parseInt(d["id"]);
        this.load();
      }
    });
  }
  load() {
    this.stuffService.getStuff(this.id).then(r => (this.stuff = r));
  }
  ngOnInit() {}
}
