import { Component, OnInit, AfterViewInit } from "@angular/core";
import { StuffService, StuffModel } from "../stuff.service";
@Component({
  selector: "app-list",
  templateUrl: "./list.component.html",
  styleUrls: ["./list.component.css"]
})
export class ListComponent implements OnInit, AfterViewInit {
  stuffs: StuffModel[] = [];
  constructor(private stuffSerivce: StuffService) {}

  ngOnInit() {
    this.stuffSerivce.getStuffs().then(r => (this.stuffs = r));
  }
  ngAfterViewInit(): void {}
}
