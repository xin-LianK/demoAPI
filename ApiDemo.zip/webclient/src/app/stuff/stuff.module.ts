import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { StuffComponent } from "./stuff.component";
import { AddComponent } from "./add/add.component";
import { StuffService } from "./stuff.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { StuffRoutes } from "./stuff.routing";
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';
@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, StuffRoutes],
  declarations: [StuffComponent, AddComponent,
    ListComponent,
    DetailComponent
],
  providers: [StuffService]
})
export class StuffModule {}
