/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { StuffService } from './stuff.service';

describe('Service: Stuff', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StuffService]
    });
  });

  it('should ...', inject([StuffService], (service: StuffService) => {
    expect(service).toBeTruthy();
  }));
});