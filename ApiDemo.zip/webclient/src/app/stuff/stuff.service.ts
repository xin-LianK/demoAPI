import { environment } from "./../../environments/environment";
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class StuffService {
  constructor(private http: HttpClient) {}

  addStuff(model: StuffModel): Promise<void> {
    return this.http
      .post<void>(`${environment.apiBase}/api/stuff/addstuff`, model)
      .toPromise();
  }
  getStuffs(): Promise<StuffModel[]> {
    return this.http
      .get<StuffModel[]>(`${environment.apiBase}/api/stuff/getstuffs`)
      .toPromise();
  }
  getStuff(id: number): Promise<StuffModel> {
    return this.http
      .get<StuffModel>(`${environment.apiBase}/api/stuff/getstuff`, {
        params: {
          id: `${id}`
        }
      })
      .toPromise();
  }
}
export class StuffModel {
  Id?: number;
  Name?: string;
  Count?: number;
}
