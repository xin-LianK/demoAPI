/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { TokenInterceptService } from './token-intercept.service';

describe('Service: TokenIntercept', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TokenInterceptService]
    });
  });

  it('should ...', inject([TokenInterceptService], (service: TokenInterceptService) => {
    expect(service).toBeTruthy();
  }));
});