import { Injectable } from "@angular/core";
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler
} from "@angular/common/http";
@Injectable()
export class TokenInterceptService implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const token = window.sessionStorage.getItem("token");

    const authReq = req.clone({ headers: req.headers.set('Authorization', `bearer ${token}`) });
    return next.handle(authReq);
  }
  constructor() {}
}
